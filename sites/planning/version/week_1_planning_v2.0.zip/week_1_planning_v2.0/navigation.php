<nav>
    <a href="home.php" class="navstart">Leerdoel</a>
    <a href="onderwerpen.php" class="navmiddel">Onderwerpen beheer</a>
    <a href="weekplanning.php" class="navend">Week planning</a>

</nav>
