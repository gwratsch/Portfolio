<!DOCTYPE html>
<html lang="nl">
    <?php
    header("location: home.php");
    exit;
    ?>
</html>
