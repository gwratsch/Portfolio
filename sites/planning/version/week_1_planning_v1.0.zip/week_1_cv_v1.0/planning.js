function hideDisplayInfo(row){
    var displayInfo = document.getElementById(row).style.display;
    if(displayInfo == 'block'){
        document.getElementById(row).style.display = 'none';
    }else{
        document.getElementById(row).style.display = 'block';
    }
}


