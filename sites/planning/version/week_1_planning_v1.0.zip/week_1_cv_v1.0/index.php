<?php
    include_once 'planning.php';
    if(array_key_exists('submit', $_POST)){
        if($_POST['submit'] == "Verzenden"){
            saveFormResult();
            $_POST["submit"] = "verwerkt";
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=devide-width, initial-scale=1.0">
        <title>Studie planning</title>
        <link rel='stylesheet' href="planning.css">
        <script src="planning.js"></script>
    </head>
    <body>
        <header class="headerblock">
            <h1>Studie planning G. Ratsch</h1>
            <img src="gratsch.jpg" alt="Picture G Ratsch">
        </header>
        <?php echo  buildhtml(); ?>
        <footer></footer>
    </body>
</html>
