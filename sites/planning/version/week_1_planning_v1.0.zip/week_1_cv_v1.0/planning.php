<?php

function datalist(){
    $datalist = array(
      "Front_end development"=>array(
          "HTML"=>"info html",
          "CSS"=>"info css",
          "Bootstrap"=>"info bootstrap",
          "Javascript"=>"",
          "Angular"=>"info Angular"
      ),
      "Back-end development"=>array(
          "PHP"=>"",
          "Laravel"=>"",
          "MySQL"=>"",
          "Linux"=>""
      ),
      "General develoment"=>array(
          "Scrum"=>"",
          "IDE"=>"",
          "Version control"=>"",
          "Cloud deployment"=>"",
          "OWASP websecurity"=>""
      ),
      "Soft skills"=>array(
          "Self improvement"=>"",
          "Communication"=>"",
          "Problem solving"=>"",
          "Time management"=>""
      )
        
    );
    return $datalist;
}
function buildhtml(){
    $dataArray= datalist();
    $content='<section class="formheadsection"><h2>Onderwerpen</h2><form action="index.php" method="post">';
    $counter = 0;
    foreach($dataArray as $groupname=>$subjects){
        $content .= '<section class="formblock"><h2 onclick="hideDisplayInfo('.'\''.$groupname.'\''.');">'.$groupname.'</h2><div id="'.$groupname.'" style="display:block">';
        $groupcontent = groupContent($subjects, $counter);
        $content .= $groupcontent['content'];
        $counter = $groupcontent['counter'];
        $content .= '</div></section>';
    }
    $content .= '<div class="submit"><input type="submit" name="submit"></div>';
    $content .= '</form></section>';
    return $content;
}
function groupContent($subjects, $counter){
    $contentresult='';
    $settings = readFormResult();
    foreach($subjects as $objectname=>$objectinfo){
        $checkObject = "";
        if(array_key_exists($objectname,$settings)){
            $checkObject="checked";
        }
        $row = "objectinfo".$counter++;
        $contentresult .= '<input type="checkbox" name="'.$objectname.'" '.$checkObject.'><label onclick="hideDisplayInfo('.'\''.$row.'\''.');">'.$objectname.'</label><br />';
        $contentresult .= '<p id="'.$row.'" style="display:none">'.$objectinfo.'</p>';
    }
    $result=array(
        "content"=>$contentresult,
        "counter"=>$counter
    );
   return $result;
}

function formResults(){
    $formresult = $_POST;
    return $formresult;
    
}
function saveFormResult(){
    $planningfile= fopen('planninformresult.txt','w');
    $content = json_encode(formResults());
    fwrite($planningfile,$content);
    fclose($planningfile);
}
function readFormResult(){
    $result=array();
    $path = 'planninformresult.txt';
    if(file_exists($path)){
        $planningfile= fopen($path,"r");
        $contenttext = fread($planningfile, filesize($path));
        $result = json_decode($contenttext);
        
    }
    return $result;
}